from flask import Flask, render_template, request, redirect, url_for,flash
from werkzeug.utils import secure_filename
import requests
import os

app = Flask(__name__)

# アップロード設定
UPLOAD_FOLDER = './uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

BASE_API_URL = "http://192.168.11.2:5015/api/"

# ファイルの拡張子チェック
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/management', methods=['GET', 'POST'])
def management():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == "add_item":
            name = request.form.get('name')
            quantity = request.form.get('quantity')
            data = {"name": name, "quantity": quantity}
            requests.post(BASE_API_URL + 'addItem', json=data)
        elif action == "reset_db":
            requests.post(BASE_API_URL + 'resetItemDB')

    items = requests.get(BASE_API_URL + 'getAllItems').json()
    return render_template('management.html', items=items)

@app.route('/upload', methods=['POST'])
def upload():
    # check if the post request has the file part
    if 'image' not in request.files:
        flash('No file part')
        return redirect(request.url)
    file = request.files['image']
    # if user does not select file, browser also
    # submit an empty part without filename
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        return redirect(url_for('management'))

if __name__ == '__main__':
    app.run(host='localhost', port=5015, debug=True)
